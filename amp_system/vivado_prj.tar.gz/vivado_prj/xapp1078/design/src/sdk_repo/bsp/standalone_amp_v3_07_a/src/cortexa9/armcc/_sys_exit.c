
// Stuv for exit() sys-call
void $Sub$$_sys_exit(int rc)
{
   while(1);
}
