
// Stub for open sys-call
int $Sub$$_sys_open(const char* name, int openmode)
{
   return 0;
}
